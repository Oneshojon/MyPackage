# my package
This package was built as an example of how to publish your own package
# How to install
"""